import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class shouldaPutARingOnIt extends PApplet {



Ring[] rings; // Declare the array
int numRings = 100;
int currentRing = 0; 
boolean rand=false;

public void setup() {
  //size(600, 600);
  rings = new Ring[numRings]; // Create the array
  for (int i = 0; i < rings.length; i++) {
    rings[i] = new Ring(); // Create each object
  }
  
}
public void draw() {
  background(0);
  for (int i = 0; i < rings.length; i++) {
    rings[i].grow();
    rings[i].display();
  }
}
// Click to create a new Ring
public void mousePressed() {
  rings[currentRing].start(mouseX, mouseY);
  currentRing++;
  if (currentRing >= numRings) {
    currentRing = 0;
  }
}
public void mouseDragged() { // Move black circle
  mousePressed();
}
public void keyPressed() {
  if (key == ' ') {
    background(0);
    for (int i =0;i<rings.length;i++){
      rings[i].on=false;
    }
  } else if (key == 'r'){
    rand = !rand;
  }
}
class Ring {
  float x, y;          // X-coordinate, y-coordinate
  float diameter;      // Diameter of the ring
  boolean on = false;  // Turns the display on and off
  float rate;

  public void start(float xpos, float ypos) {
    x = xpos;
    y = ypos; 
    rate = random(1,50);
    diameter = 1;
    on = true;
  }
  
  public void grow() {
    if (on == true) {
      if(rand) diameter += 0.5f*rate;
      else diameter += 5;
      if (diameter > width+200 && diameter >height+200) {
        on = false;
       diameter = 1;
      }
    }
  }

  public void display() {
    if (on == true) {
      noFill();
      strokeWeight(4);
      stroke(204, 153);
      ellipse(x, y, diameter, diameter);
    }
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "shouldaPutARingOnIt" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
